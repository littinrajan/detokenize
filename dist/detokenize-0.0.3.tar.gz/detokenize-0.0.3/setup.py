from setuptools import setup

setup(name='detokenize',
      version='0.0.3',
      description='Detokenize stream of tokens',
      packages=['detokenize'],
      author_email='littinrajan@gmail.com',
      zip_safe=False)
